<?php

/*

Plugin Name: Wp Dev Plugin
Plugin URI: https://github.com/ImDR/wp-dev-plugin
Description: Wp Dev Plugin by ImDR
Version: 1.0
Author: Dinesh Rawat
Author URI: https://imdr.github.io/

*/

define('WPDEV_PLUGIN',  plugin_dir_url(__FILE__));

//echo WPDEV_PLUGIN;

include_once('includes/wpdev-plugin-user.php');
include_once('includes/wpdev-plugin-objects.php');
include_once('includes/wpdev-plugin-relationships.php');
include_once('includes/wpdev-plugin-meta-controls.php');
include_once('includes/wpdev-plugin-dashboard.php');
include_once('includes/ajax_request_handle.php');
include_once('includes/wpdev-plugin-page.php');

include_once('includes/wpdev-plugin-objects-init.php');
include_once('includes/wpdev-plugin-meta-control-init.php');
include_once('includes/wpdev-plugin-theme-options-init.php');


register_activation_hook( __FILE__, 'wpdev_plugin_setup');

function wpdev_plugin_setup(){
	global $wpdb;
	$charset = $wpdb->get_charset_collate();
	$table1 = $wpdb->prefix.'wpdev_meta_controls';
	$table2 = $wpdb->prefix.'wpdev_posts_tax_rel';
	$table3 = $wpdb->prefix.'wpdev_post_tax';

	require_once(ABSPATH.'wp-admin/includes/upgrade.php');

	if($wpdb->get_var("show tables like '$table1'") != $table1){
		$sql = "CREATE TABLE $table1 ( 
			`control_id` INT NOT NULL AUTO_INCREMENT , 
			`control_type` text NOT NULL,
  			`control_name` text NOT NULL,
  			`control_label` text NOT NULL,
  			`post_type` text NOT NULL,
  			`template_name` text NOT NULL,
 			`control_description` text NOT NULL,
  			`control_order` int NOT NULL,
			PRIMARY KEY (`control_id`)
		) $charset;";
		dbDelta($sql);
	}

	if($wpdb->get_var("show tables like '$table2'") != $table2){
		$sql = "CREATE TABLE $table2 ( 
			`id` INT NOT NULL AUTO_INCREMENT , 
			`post_type_name` text NOT NULL,
  			`taxonomy_name` text NOT NULL,
			PRIMARY KEY (`id`)
		) $charset;";
		dbDelta($sql);
	}

	if($wpdb->get_var("show tables like '$table3'") != $table3){
		$sql = "CREATE TABLE $table3 ( 
			`object_id` INT NOT NULL AUTO_INCREMENT , 
			`object_type` text,
			`object_name` text,
			`object_support` text,
			`singular_name` text,
			`plural_name` text,
			`hierarchical` varchar(10) DEFAULT NULL,
			`dashicon_class` text,
			`menu_position` tinyint(4) DEFAULT NULL,
			PRIMARY KEY (`object_id`)
		) $charset;";
		dbDelta($sql);
	}

	$user = new WPDEV_User();
	$user->setDefault();
}

add_action( 'admin_init', 'wpdev_plugin_scripts' );

function wpdev_plugin_scripts(){
	wp_enqueue_style( 'wpdev_plugin_style', WPDEV_PLUGIN.'css/style.css', array(), '1.0' );
	
	wp_enqueue_script('jquery');
	wp_enqueue_script( 'Sortable_min', WPDEV_PLUGIN.'js/Sortable.min.js', array(), '1.0', true );
	wp_enqueue_script( 'image_upload', WPDEV_PLUGIN.'js/image-upload.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'wpdev_plugin_ajax', WPDEV_PLUGIN.'js/ajax-handle.js', array('jquery','Sortable_min'), '1.0', true );
	wp_localize_script( 'wpdev_plugin_ajax', 'ajax_object', array('ajax_url'=> admin_url('admin-ajax.php')) );
}