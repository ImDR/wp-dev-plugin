<?php

class WPDEV_Meta_Controls{
	
	private $db_table;
	private $db;

	function __construct(){
		global $wpdb;
		$this->db = $wpdb;
		$this->db_table = $wpdb->prefix.'wpdev_meta_controls';	
	}

	public function createControl($control_type, $control_name, $control_label, $post_type, $template_name, $control_description, $control_order){
		$result = $this->db->insert($this->db_table, array(
			'control_type' => $control_type, 
			'control_name' => $control_name, 
			'control_label' => $control_label, 
			'post_type'=> $post_type, 
			'template_name'=> $template_name, 
			'control_description'=> $control_description,
			'control_order'=>$control_order
			)
		);
		return $result;
	}

	public function editControl($control_id, $control_label, $control_description){
		$result = $this->db->update($this->db_table, array(
			'control_label' => $control_label, 
			'control_description'=> $control_description
			), array('control_id'=>$control_id));
		return $result;
	}

	public function checkPostHasMeta($post_type){
		$result = $this->db->get_var("SELECT count(*) FROM ". $this->db_table ." where post_type = '$post_type'");
		if($result>0){
			return true;
		}
		return false;
	}

	public function checkPageHasMeta($template){
		$result = $this->db->get_var("SELECT count(*) FROM ". $this->db_table ." where post_type = 'page' and 
			template_name = '$template'");
		if($result>0){
			return true;
		}
		return false;
	}

	public function removeControlById($control_id){
		$result = $this->db->delete($this->db_table, array('control_id'=>$control_id));
		return $result;
	}

	public function changeOrder($control_id, $control_order){
		$result = $this->db->update($this->db_table, array(
			'control_order' => $control_order
			), array('control_id'=>$control_id));
		return $result;
	}

	public function getControlsHtml($result){
		if(!empty($result)){
			foreach ($result as $key => $control) {
				$control = get_object_vars($control);
			?>
			<li data-control-id="<?php echo $control['control_id']; ?>">
				<div class="collapse-box">
					<div class="collapse-head">
						<h4><?php echo ucwords(str_replace('-',' ', $control['control_type'])); ?>
						<i> (<?php echo ($control['control_type']=='tab')?$control['control_label']:$control['control_name']; ?>) </i></h4>
						<span class="remove-control" ><img src="<?php echo WPDEV_PLUGIN; ?>img/close.png" /></span>
						<span class="toggle-btn"><img src="<?php echo WPDEV_PLUGIN; ?>img/chevron-down.png" /></span>
						<span class="handle"><img src="<?php echo WPDEV_PLUGIN; ?>img/arrows.png"></span>
					</div>
					<div class="collapse-body">
						<form method="post" class="wpdev-updatemetacontrol">
						<div class="row-field">
							<input type="text" name="wpdev-mbcontrollabel" placeholder="Label *" value="<?php echo $control['control_label']; ?>" required>
						</div>
						<?php
							if($control['control_type']!='tab'){
							?>
							<div class="row-field">
								<textarea name="wpdev-mbcontroldescription" style="resize: none;" rows="4" placeholder="Message"><?php echo $control['control_description']; ?></textarea>
							</div>
							<?php	
							}
						?>
						
						<div class="row-field">
							<input type="hidden" name="wpdev-control-id" value="<?php echo $control['control_id']; ?>"/>
							<input type="submit" class="bgcolor-yellow" value="Update Meta Control"/>
						</div>
						</form>
					</div>
				</div>
			</li>
			<?php
			}
		}
	}

	public function getPageControlsHtml($post_type, $template){
		?>
		<div class="card">
		<h3>Page Template: <?php echo $template; ?></h3>
		<ol id="controls-list">
		<?php 
		$result = $this->getControlsArray($post_type, $template);
		$this->getControlsHtml($result);
		?>
		</ol>
		<hr/>
		<br/>
		<div class="collapse-box">
			<div class="collapse-head">
				<h4>Create New Meta Control</h4>
				<span class="toggle-btn"><img src="<?php echo WPDEV_PLUGIN; ?>img/chevron-down.png" /></span>
			</div>
			<div class="collapse-body">
				<form method="post" class="wpdev-createmetacontrol">
				<div class="row-field">
					<select name="wpdev-mbcontroltype" required>
						<option disabled selected>- - - Select Meta Control Type * - - -</option>
						<option value="tab">Tab</option>
						<option value="text-box">Text Box</option>
						<option value="textarea">Textarea</option>
						<option value="wp_editor">WP Editor</option>
						<option value="check-box">Check Box</option>
						<option value="select-box">Select Box</option>
						<option value="date-picker">Date Picker</option>
						<option value="color-picker">Color Picker</option>
						<option value="image-upload">Image Upload</option>
						<option value="image-gallery-upload">Image Gallery Upload</option>
						<option value="object-upload">Object Upload</option>
					</select>
				</div>
				<div class="row-field">
					<input type="text" name="wpdev-mbcontrolname" pattern="[a-zA-Z0-9_-]+" title="only a-z, A-Z, 0-9, - and _" placeholder="Variable Name *">
				</div>
				<div class="row-field">
					<input type="text" name="wpdev-mbcontrollabel" placeholder="Label *" required>
				</div>
				<div class="row-field">
					<textarea name="wpdev-mbcontroldescription" style="resize: none;" rows="4" placeholder="Message"></textarea>
				</div>
				<div class="row-field">
					<input type="hidden" name="wpdev-post-type" value="page"/>
					<input type="hidden" name="wpdev-template-name" value="<?php echo $template; ?>"/>
					<input type="submit" class="bgcolor-red" value="Add Meta Control"/>
				</div>
				</form>
			</div>
		</div>
			
		</div>
		<?php
	}

	public function getPostControlsHtml($post_type){
		?>
		<div class="card">
		<h3>Post Type: <?php echo $post_type; ?></h3>
		<ol id="controls-list">
		<?php 
		$result = $this->getControlsArray($post_type);
		$this->getControlsHtml($result);
		?>
		</ol>
		<hr/>
		<br/>
		<div class="collapse-box">
			<div class="collapse-head">
				<h4>Create New Meta Control</h4>
				<span class="toggle-btn"><img src="<?php echo WPDEV_PLUGIN; ?>img/chevron-down.png" /></span>
			</div>
			<div class="collapse-body">
				<form method="post" class="wpdev-createmetacontrol">
				<div class="row-field">
					<select name="wpdev-mbcontroltype" required>
						<option disabled selected>- - - Select Meta Control Type * - - -</option>
						<option value="tab">Tab</option>
						<option value="text-box">Text Box</option>
						<option value="textarea">Textarea</option>
						<option value="wp_editor">WP Editor</option>
						<option value="check-box">Check Box</option>
						<option value="select-box">Select Box</option>
						<option value="date-picker">Date Picker</option>
						<option value="color-picker">Color Picker</option>
						<option value="image-upload">Image Upload</option>
						<option value="image-gallery-upload">Image Gallery Upload</option>
						<option value="object-upload">Object Upload</option>
					</select>
				</div>
				<div class="row-field">
					<input type="text" name="wpdev-mbcontrolname" pattern="[a-zA-Z0-9_-]+" title="only a-z, A-Z, 0-9, - and _" placeholder="Variable Name *">
				</div>
				<div class="row-field">
					<input type="text" name="wpdev-mbcontrollabel" placeholder="Label *" required>
				</div>
				<div class="row-field">
					<textarea name="wpdev-mbcontroldescription" style="resize: none;" rows="4" placeholder="Message"></textarea>
				</div>
				<div class="row-field">
					<input type="hidden" name="wpdev-post-type" value="<?php echo $post_type; ?>"/>
					<input type="submit" class="bgcolor-green" value="Add Meta Control"/>
				</div>
				</form>
			</div>
		</div>
			
		</div>
		<?php
	}

	public function postTypeHasMeta($post_type, $control_name){
		$result = $this->db->get_results( "SELECT * FROM ".$this->db_table." where `post_type` = '$post_type' AND `control_name` = '$control_name' and control_type !='tab'" );
		if(count($result)==0){
			return true;
		}

		return false;
	}

	public function getControlsArray($post_type, $template=''){
		if($template!=''){
			$result = $this->db->get_results( "SELECT * FROM ".$this->db_table." where `post_type` = '$post_type' AND `template_name` = '$template' ORDER BY `control_order` ASC" );
		}else{
			$result = $this->db->get_results( "SELECT * FROM ".$this->db_table." where `post_type` = '$post_type' ORDER BY `control_order` ASC" );
		}
		
		return $result;
	}

}

?>