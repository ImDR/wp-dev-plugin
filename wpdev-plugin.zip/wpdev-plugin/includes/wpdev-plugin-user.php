<?php


class WPDEV_User
{
	
	function __construct()
	{
		
	}

	public function login($password){
		if(md5($password) == get_option('wpdev-plugin-pswd','')){
			return true;
		}

		return false;
	}

	public function setDefault(){
		update_option('wpdev-plugin-pswd', md5('developer'));
	}

	public function change_password($password, $newPassword, $newPassword2){
		if($this->login($password)){
			if($newPassword == $newPassword2){
				update_option('wpdev-plugin-pswd', md5($newPassword));
				return "ok";
			}else{
				return "Password does not match the confirm password.";
			}
		}else{
			return "Current password do not match.";
		}
	}
}

?>