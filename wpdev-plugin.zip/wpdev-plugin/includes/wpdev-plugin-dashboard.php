<?php


class WPDEV_Dashboard
{
	
	function __construct()
	{
		
	}

	public function getDashboard(){
	?>
	<h2 class="nav-tab-wrapper wpdev-dashboard-menu">
		<span class="nav-tab nav-tab-active" data-menu-name="custom-posts">Custom Posts</span>
		<span class="nav-tab" data-menu-name="custom-taxonomies">Custom Taxonomies</span>
		<span class="nav-tab" data-menu-name="rel-posts-taxonomies">Relation Posts Taxonomies</span>
		<span class="nav-tab" data-menu-name="meta-builder">Meta Builder</span>
		<span class="nav-tab" data-menu-name="change-password">Change Password</span>
		
		<span class="alignright">
			<span class="response-text"></span>
			<button class="reload bgcolor-red">Reload</button>
		</span>
	</h2>
	<div id="wpdev-dashboard-container">
		<?php

		$this->customPosts();
		?>
	</div>
	<?php
	}

	public function changePassword(){
		?>
		<div class="card" style="max-width:300px;">
			<h2><?php echo __('Change Password', 'wpdev-plugin'); ?></h2>
			<form method="post" class="wpdev-changepswd-form">
				<div class="row-field">
					<input type="password" placeholder="Current Password *" name="wpdev-plugin-pswd" required/>
				</div>
				<div class="row-field">
					<input type="password" placeholder="New Password *" name="wpdev-plugin-new-pswd" required/>
				</div>
				<div class="row-field">
					<input type="password" placeholder="Confirm Password *" name="wpdev-plugin-new2-pswd" required/>
				</div>
				<div class="row-field">
					<input type="submit" class="bgcolor-green" value="Change Password"/>
				</div>
			</form>
		</div>
		<?php
	}

	public function customPosts(){
		?>
		<div class="card col" style="max-width:300px;">
			<h2><?php echo __('Create Custom Post', 'wpdev-plugin'); ?></h2>
			<form method="post" class="wpdev-createcustompost">
				<div class="row-field">
					<input type="text" placeholder="Post Name *" name="wpdev-post-name" pattern="[a-z0-9_]+" title="only a-z, 0-9 and _" required/>
				</div>
				<div class="row-field">
					<input type="text" placeholder="Singular Name (Label) *" name="wpdev-singular-name" required/>
				</div>
				<div class="row-field">
					<input type="text" placeholder="Plural Name (Label) *" name="wpdev-plural-name" required/>
				</div>
				<div class="row-field">
					<input type="text" placeholder="Dashicon Class or Image url" name="wpdev-dashicon-class" />
				</div>
				<div class="row-field">
					<input type="text" placeholder="Menu Position" name="wpdev-menu-position" pattern="[0-9]+" title="Numbers Only" maxlength="2"/>
				</div>
				
				<div class="row-field">
					<p><?php echo __('Post Supports (selected: title)', 'wpdev-plugin'); ?></p>
					<input type="checkbox" name="wpdev-post-support" value="editor" id="editor-chkbox"> <label for="editor-chkbox">Editor</label><br/>
					<input type="checkbox" name="wpdev-post-support" value="author" id="author-chkbox"> <label for="author-chkbox">Author</label><br/>
					<input type="checkbox" name="wpdev-post-support" value="thumbnail" id="thumbnail-chkbox"> <label for="thumbnail-chkbox">Thumbnail</label><br/>
					<input type="checkbox" name="wpdev-post-support" value="excerpt" id="excerpt-chkbox"> <label for="excerpt-chkbox">Excerpt</label><br/>
					<input type="checkbox" name="wpdev-post-support" value="comments" id="comments-chkbox"> <label for="comments-chkbox">Comments</label><br/>
					<input type="checkbox" name="wpdev-post-support" value="page-attributes" id="page-attributes-chkbox"> <label for="page-attributes-chkbox">Page Attributes</label>
				</div>
				<div class="row-field">
					<input type="submit" class="bgcolor-blue" value="Create Post"/>
				</div>
			</form>
		</div>
		<div class="card col" style="max-width:450px;">
			<h2><?php echo __('All Custom Posts', 'wpdev-plugin'); ?></h2>
			<?php 
			$object = new WPDEV_Objects();
			$result = $object->getObjectsByType('post');
			if(!empty($result)){
				foreach ($result as $value) {
					$object = get_object_vars($value);
				?>
					<div class="collapse-box">
						<div class="collapse-head">
							<h4>Post Type: <b><i><?php echo $object['object_name']; ?></i></b></h4>
							<span class="remove" data-objectId = "<?php echo esc_attr($object['object_id']); ?>"><img src="<?php echo WPDEV_PLUGIN; ?>img/close.png" /></span>
							<span class="toggle-btn"><img src="<?php echo WPDEV_PLUGIN; ?>img/chevron-down.png" /></span>
						</div>
						<div class="collapse-body">
							<form method="post" class="wpdev-editcustompost">
								<div class="row-field">
									<input type="text" placeholder="Singular Name (Label) *" name="wpdev-singular-name" value="<?php echo esc_attr($object['singular_name']); ?>" required/>
								</div>
								<div class="row-field">
									<input type="text" placeholder="Plural Name (Label) *" name="wpdev-plural-name" value="<?php echo esc_attr($object['plural_name']); ?>" required/>
								</div>
								<div class="row-field">
									<input type="text" placeholder="Dashicon Class or Image url" name="wpdev-dashicon-class" value="<?php echo esc_attr($object['dashicon_class']); ?>" />
								</div>
								<div class="row-field">
									<input type="text" placeholder="Menu Position" name="wpdev-menu-position" value="<?php echo esc_attr($object['menu_position']); ?>" pattern="[0-9]+" title="Numbers Only" maxlength="2"/>
								</div>
							
								<div class="row-field">
									<p><?php echo __('Post Supports (selected: title)', 'wpdev-plugin'); ?></p>
									<?php
										preg_match_all('/"([^"]*)"/',stripcslashes($object['object_support']), $options); 
										//print_r($options[1]);
										
									?>
									<input type="checkbox" name="wpdev-post-support" value="editor" id="editor-chkbox-<?php echo esc_attr($object['object_id']); ?>" 
									<?php echo (in_array("editor", $options[1]))?'checked':''; ?>> <label for="editor-chkbox-<?php echo esc_attr($object['object_id']); ?>">Editor</label><br/>
									<input type="checkbox" name="wpdev-post-support" value="author" id="author-chkbox-<?php echo esc_attr($object['object_id']); ?>" 
									<?php echo (in_array("author", $options[1]))?'checked':''; ?>> <label for="author-chkbox-<?php echo esc_attr($object['object_id']); ?>">Author</label><br/>
									<input type="checkbox" name="wpdev-post-support" value="thumbnail" id="thumbnail-chkbox-<?php echo esc_attr($object['object_id']); ?>"
									<?php echo (in_array("thumbnail", $options[1]))?'checked':''; ?>> <label for="thumbnail-chkbox-<?php echo esc_attr($object['object_id']); ?>">Thumbnail</label><br/>
									<input type="checkbox" name="wpdev-post-support" value="excerpt" id="excerpt-chkbox-<?php echo esc_attr($object['object_id']); ?>" 
									<?php echo (in_array("excerpt", $options[1]))?'checked':''; ?>> <label for="excerpt-chkbox-<?php echo esc_attr($object['object_id']); ?>">Excerpt</label><br/>
									<input type="checkbox" name="wpdev-post-support" value="comments" id="comments-chkbox-<?php echo esc_attr($object['object_id']); ?>"
									<?php echo (in_array("comments", $options[1]))?'checked':''; ?>> <label for="comments-chkbox-<?php echo esc_attr($object['object_id']); ?>">Comments</label><br/>
									<input type="checkbox" name="wpdev-post-support" value="page-attributes" id="page-attributes-chkbox-<?php echo esc_attr($object['object_id']); ?>" <?php echo (in_array("page-attributes", $options[1]))?'checked':''; ?>> <label for="page-attributes-chkbox-<?php echo esc_attr($object['object_id']); ?>">Page Attributes</label>
								</div>
								<div class="row-field">
									<input type="hidden" value="<?php echo esc_attr($object['object_id']); ?>" name="wpdev-post-id">
									<input type="submit" class="bgcolor-yellow" value="Edit Post"/>
								</div>
							</form>
						</div>
					</div>
				<?php
				}
			}
			
			?>
			
		</div>
		<?php
	}

	public function customTaxonomy(){
	?>
		<div class="card col" style="max-width:300px;">
			<h2><?php echo __('Create Custom Taxonomy', 'wpdev-plugin'); ?></h2>
			<form method="post" class="wpdev-createcustomtaxonomy">
				<div class="row-field">
					<input type="text" placeholder="Taxonomy Name *" name="wpdev-taxo-name" pattern="[a-z0-9_]+" title="only a-z, 0-9 and _" required/>
				</div>
				<div class="row-field">
					<input type="text" placeholder="Singular Name (Label) *" name="wpdev-singular-name" required/>
				</div>
				<div class="row-field">
					<input type="text" placeholder="Plural Name (Label) *" name="wpdev-plural-name" required/>
				</div>
				<div class="row-field">
					<input type="checkbox" name="wpdev-taxo-thumbnail" value="thumbnail" id="thumbnail-chkbox"> <label for="thumbnail-chkbox">Thumbnail Supports</label><br/>
				</div>
				<div class="row-field">
					<input type="checkbox" name="wpdev-taxo-hierarchical" value="true" id="hierarchical-chkbox"> <label for="hierarchical-chkbox">Hierarchical</label><br/>
				</div>
				
				<div class="row-field">
					<input type="submit" class="bgcolor-red" value="Create Taxonomy"/>
				</div>
			</form>
		</div>
		<div class="card col" style="max-width:450px;">
			<h2><?php echo __('All Custom Taxonomies', 'wpdev-plugin'); ?></h2>
			<?php 
			$object = new WPDEV_Objects();
			$result = $object->getObjectsByType('taxonomy');
			
			if(!empty($result)){
				foreach ($result as $value) {
					$object = get_object_vars($value);
				?>
					<div class="collapse-box">
						<div class="collapse-head">
							<h4>Post Type: <b><i><?php echo $object['object_name']; ?></i></b></h4>
							<span class="remove" data-objectId = "<?php echo esc_attr($object['object_id']); ?>"><img src="<?php echo WPDEV_PLUGIN; ?>img/close.png" /></span>
							<span class="toggle-btn"><img src="<?php echo WPDEV_PLUGIN; ?>img/chevron-down.png" /></span>
						</div>
						<div class="collapse-body">
							<form method="post" class="wpdev-editcustomtaxonomy">
								<div class="row-field">
									<input type="text" placeholder="Singular Name (Label) *" name="wpdev-singular-name" value="<?php echo esc_attr($object['singular_name']); ?>" required/>
								</div>
								<div class="row-field">
									<input type="text" placeholder="Plural Name (Label) *" name="wpdev-plural-name" value="<?php echo esc_attr($object['plural_name']); ?>" required/>
								</div>
								<div class="row-field">
									<input type="checkbox" name="wpdev-taxo-thumbnail" value="thumbnail" id="thumbnail-chkbox-<?php echo esc_attr($object['object_id']); ?>" <?php echo esc_attr($object['object_support']=='true')? 'checked':''; ?>> <label for="thumbnail-chkbox-<?php echo esc_attr($object['object_id']); ?>">Thumbnail Supports</label><br/>
								</div>
								<div class="row-field">
									<input type="checkbox" name="wpdev-taxo-hierarchical" value="true" id="hierarchical-chkbox-<?php echo esc_attr($object['object_id']); ?>" <?php echo esc_attr($object['hierarchical']=='true')? 'checked':''; ?>> <label for="hierarchical-chkbox-<?php echo esc_attr($object['object_id']); ?>">Hierarchical</label><br/>
								</div>
								
								<div class="row-field">
									<input type="hidden" value="<?php echo esc_attr($object['object_id']); ?>" name="wpdev-taxo-id">
									<input type="submit" class="bgcolor-green" value="Edit Taxonomy"/>
								</div>
							</form>
						</div>
					</div>
				<?php
				}
			}
				
			?>
		</div>
	<?php
	}

	public function relPostTaxonomy(){
		?>
		<div class="card col" style="max-width:350px;">
			<h2><?php echo __('Create Relationship', 'wpdev-plugin'); ?></h2>
			<form method="post" class="wpdev-relposttaxonomy">
				<div class="row-field">
					<select name="wpdev-rel-post" required>
						<option disabled selected>- - - Select Post * - - -</option>
						<?php
						$res = get_post_types(array('public'=>true));
						unset($res['attachment']);
						
						if(!empty($res)){
							foreach ($res as $value) {
							?>
							<option value="<?php echo esc_attr($value); ?>"><?php echo $value; ?></option>
							<?php
							}
						}
						?>
						
					</select>	
				</div>
				<div class="row-field">
					<select name="wpdev-rel-taxonomy" required>
						<option disabled selected>- - - Select Taxonomy * - - -</option>
						<?php
						$res = get_taxonomies(array('_builtin'=> false));
						if(!empty($res)){
							foreach ($res as $value) {
							?>
							<option value="<?php echo esc_attr($value); ?>"><?php echo $value; ?></option>
							<?php
							}
						}
						?>
						
					</select>	
				</div>
				<div class="row-field">
					<input type="submit" class="bgcolor-blue" value="Create Relationship"/>
				</div>
			</form>
		</div>
		<div class="card col" style="max-width:400px;">
			<h2><?php echo __('All Relationships', 'wpdev-plugin'); ?></h2>
			<?php
				$rel = new WPDEV_Relationships();
				$relationshipArr = $rel->getAllRelationships();
				if(!empty($relationshipArr)){
					foreach($relationshipArr as $relationship){
						$relationship = get_object_vars($relationship);
					?>
						<div class="collapse-box">
							<div class="collapse-head">
								<h4>Relationship: <b><i><?php echo $relationship['post_type_name'] .", ". $relationship['taxonomy_name']; ?></i></b></h4>
								<span class="remove-rel" data-relId = "<?php echo esc_attr($relationship['id']); ?>"><img src="<?php echo WPDEV_PLUGIN; ?>img/close.png" /></span>
							</div>
						</div>
					<?php
					}
				}
			?>
			
		</div>
		<?php
	}

	public function metaBuilder(){
		?>
		<div class="card col" style="max-width:350px;">
			<h2><?php echo __('Create Meta Control', 'wpdev-plugin'); ?></h2>
			<p>Select Post Type:</p>
			<div class="row-field">
				<select name="wpdev-mbpost" required>
					<option disabled selected>- - - Select Post * - - -</option>
					<option value="theme-option">Theme Option</option>
					<?php
						$res = get_post_types(array('public'=>true));
						unset($res['attachment']);
						
						if(!empty($res)){
							foreach ($res as $value) {
							?>
							<option value="<?php echo esc_attr($value); ?>"><?php echo $value; ?></option>
							<?php
							}
						}
					?>
				</select>
			</div>
			<div class="row-field">
				<select name="wpdev-mbtemplate" style="display: none;" >
					<option disabled selected>- - - Select Template * - - -</option>
					<option value="all-templates">All Templates</option>
					<option value="default-template">Default Template</option>
					<?php
						$res = get_page_templates();
						
						if(!empty($res)){
							foreach ($res as $value) {
							?>
							<option value="<?php echo esc_attr($value); ?>"><?php echo $value; ?></option>
							<?php
							}
						}
					?>
				</select>
			</div>
		</div>
		<div class="metaBuilderContainer col">
			
		</div>
		<?php
	}
}