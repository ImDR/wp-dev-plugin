<?php

function WP_Dev_init_objects() {
	$objectVar = new WPDEV_Objects();
	$result = $objectVar->getObjectsByType('post');
	if(!empty($result)){
		foreach ($result as $value) {
			$object = get_object_vars($value);
			if(!post_type_exists($object['object_name'])){
				preg_match_all('/"([^"]*)"/',stripcslashes($object['object_support']), $supports);
				$supports = $supports[1];
				array_push($supports, 'title');
				$labels = array(
					'name'               => _x( ucwords($object['plural_name']), 'post type general name' , 'wpdev-plugin'),
					'singular_name'      => _x( ucwords($object['singular_name']), 'post type singular name' , 'wpdev-plugin' ),
					'add_new'            => _x( 'Add New ', $object['object_name'] , 'wpdev-plugin' ),
					'add_new_item'       => __( 'Add New '. ucwords($object['singular_name']), 'wpdev-plugin' ),
					'edit_item'          => __( 'Edit '. ucwords($object['singular_name']), 'wpdev-plugin' ),
					'new_item'           => __( 'New '. ucwords($object['singular_name']), 'wpdev-plugin' ),
					'all_items'          => __( 'All '. ucwords($object['plural_name']), 'wpdev-plugin' ),
					'view_item'          => __( 'View '.ucwords($object['singular_name']) , 'wpdev-plugin'),
					'search_items'       => __( 'Search '. ucwords($object['plural_name']), 'wpdev-plugin' ),
					'not_found'          => __( 'No '. $object['plural_name'] .' found', 'wpdev-plugin' ),
					'not_found_in_trash' => __( 'No '. $object['plural_name'] .' found in the Trash', 'wpdev-plugin' ), 
					'parent_item_colon'  => '',
					'menu_name'          => ucwords($object['plural_name'])
				);
				$args = array(
					'labels'        => $labels,
					'public'		=> true,
					'menu_position' => intval($object['menu_position']),
					'menu_icon'     => $object['dashicon_class'],
					'supports'      => $supports,
					'has_archive'   => true
				);
				register_post_type( $object['object_name'], $args ); 
			}
		}
	}
	
	$result = $objectVar->getObjectsByType('taxonomy');
	if(!empty($result)){
		foreach ($result as $value) {
			$object = get_object_vars($value);
			if(!taxonomy_exists($object['object_name'])){
				$labels = array(
					'name'              => _x( ucwords($object['plural_name']), 'taxonomy general name' , 'wpdev-plugin'),
					'singular_name'     => _x( ucwords($object['singular_name']), 'taxonomy singular name', 'wpdev-plugin' ),
					'search_items'      => __( 'Search '.ucwords($object['plural_name']), 'wpdev-plugin' ),
					'all_items'         => __( 'All '.ucwords($object['plural_name']), 'wpdev-plugin' ),
					'parent_item'       => __( 'Parent '.ucwords($object['singular_name']), 'wpdev-plugin' ),
					'parent_item_colon' => __( 'Parent '.ucwords($object['singular_name']).':' , 'wpdev-plugin'),
					'edit_item'         => __( 'Edit '.ucwords($object['singular_name']), 'wpdev-plugin' ), 
					'update_item'       => __( 'Update '.ucwords($object['singular_name']), 'wpdev-plugin' ),
					'add_new_item'      => __( 'Add New '.ucwords($object['singular_name']), 'wpdev-plugin' ),
					'new_item_name'     => __( 'New '.ucwords($object['singular_name']), 'wpdev-plugin' ),
					'menu_name'         => __( ucwords($object['plural_name']), 'wpdev-plugin' ),
				);
				$args = array(
					'labels' => $labels,
					'hierarchical' => boolval($object['object_support'])					
				);
				register_taxonomy( $object['object_name'], null, $args );
			}
		}
	}
	
	$rel = new WPDEV_Relationships();
	$relationshipArr = $rel->getAllRelationships();
	if(!empty($relationshipArr)){
		foreach($relationshipArr as $relationship){
			$relationship = get_object_vars($relationship);
			if(!is_object_in_taxonomy($relationship['post_type_name'], $relationship['taxonomy_name'])){
				register_taxonomy_for_object_type($relationship['taxonomy_name'], $relationship['post_type_name']);
			}
		}
	}
	

}
add_action( 'init', 'WP_Dev_init_objects' );


?>