<?php

add_action('add_meta_boxes','WP_Dev_create_metabox');

function WP_Dev_create_metabox(){
	global $post;
	$control = new WPDEV_Meta_Controls();
	if($post->post_type=='page'){
		$result = $control->checkPageHasMeta('all-templates');
		if(!$result){
			$template = get_page_template_slug( $post->ID );
			$template= ($template=='')?'default-template':$template;
			$result = $control->checkPageHasMeta($template);
		}
		
	}else{
		$result = $control->checkPostHasMeta($post->post_type);
	}
	
	if($result){
		$metaBoxId = "wpdev-meta-".$post->post_type;
		add_meta_box($metaBoxId,'WP Dev Meta Box','WP_Dev_MB_MetaBox_Controls',$post->post_type,'normal','default');
	}
	
}

function WP_Dev_MB_MetaBox_Controls(){
	global $post;
	?>
<style type="text/css">
.wpdev-plugin.image-upload .img-preview img{
	max-height: 100px;
	max-width: 100px;
	border:1px solid #ccc;
}

.wpdev-plugin.image-gallery-upload .gallery-box ul{
	display: flex;
    max-width: 100%;
    flex-wrap: wrap;
}

.wpdev-plugin.image-gallery-upload .gallery-box ul li{
	margin-right: 15px;
    margin-bottom: 15px;
    position: relative;
    border:1px solid #ccc;
}

.wpdev-plugin.image-gallery-upload .gallery-box ul li span.remove{
	position: absolute;
    font-size: 15px;
    border: 1px solid #f75a5a;
    color: #ffffff;
    height: 16px;
    width: 16px;
    line-height: 15px;
    text-align: center;
    border-radius: 50%;
    top: -8px;
    right: -8px;
    background-color: #f75a5a;
    opacity: 0.8;
    cursor: pointer;
}

.wpdev-plugin.image-gallery-upload .gallery-box ul li span.remove:hover{
	opacity: 1;
}

.wpdev-plugin.image-gallery-upload .gallery-box ul img{
	width: 100px;
    height: 100px;
    display: block;
}

</style>
	<?php
	$control = new WPDEV_Meta_Controls();
	if($post->post_type=='page'){
		$controlList = $control->getControlsArray('page','all-templates');
		$template = get_page_template_slug( $post->ID );
		$template= ($template=='')?'default-template':$template;
		$controlList2 = $control->getControlsArray('page', $template);
		$controlList = array_merge($controlList, $controlList2);
	}else{
		$controlList = $control->getControlsArray($post->post_type);
	}

	wp_nonce_field(basename(__FILE__),'wpdev_meta_nonce');

	if(!empty($controlList)){
		foreach ($controlList as $control) {
			$control = get_object_vars($control);
			if($control['control_type']=='tab'){
			?>
			<h3><?php echo ucwords($control['control_label']); ?></h3>
			<hr/>
			<?php
			}

			if($control['control_type']=='text-box'){
			?>
			<p><b>
			<label for="<?php echo "text-box-".$control['control_id']; ?>"><?php echo ucwords($control['control_label']); ?></label></b></p>
			<input type="text" id="<?php echo "text-box-".$control['control_id']; ?>" class="widefat" name="<?php echo esc_attr($control['control_name']); ?>" value="<?php echo get_post_meta($post->ID, $control['control_name'], true); ?>">
			<p><i><?php echo $control['control_description']; ?></i></p>
			<?php
			}

			if($control['control_type']=='textarea'){
			?>
			<p><b>
			<label for="<?php echo "textarea-".$control['control_id']; ?>"><?php echo ucwords($control['control_label']); ?></label></b></p>
			<textarea id="<?php echo "textarea-".$control['control_id']; ?>" class="widefat" rows="5" style="resize: none;" name="<?php echo esc_attr($control['control_name']); ?>"><?php echo get_post_meta($post->ID, $control['control_name'], true); ?></textarea>
			<p><i><?php echo $control['control_description']; ?></i></p>
			<?php
			}

			if($control['control_type']=='wp_editor'){
			?>
			<p><b><?php echo ucwords($control['control_label']); ?></b></p>
			<?php 
			$data = get_post_meta($post->ID, $control['control_name'], true);
			wp_editor( $data, $control['control_name']);
			?>
			<p><i><?php echo $control['control_description']; ?></i></p>
			<?php
			}

			if($control['control_type']=='check-box'){
			?>
			<p>
			<input id="<?php echo "check-box-".$control['control_id']; ?>" type="checkbox" name="<?php echo esc_attr($control['control_name']); ?>" <?php echo (get_post_meta($post->ID, $control['control_name'], true) == 'on')?'checked':'';	?>>
			<b><label for="<?php echo "check-box-".$control['control_id']; ?>"><?php echo ucwords($control['control_label']); ?></label></b>
			</p>
			<p><i><?php echo $control['control_description']; ?></i></p>
			<?php
			}

			if($control['control_type']=='select-box'){
			?>
			<p><b>
			<label for="<?php echo "select-box-".$control['control_id']; ?>"><?php echo ucwords($control['control_label']); ?>:&nbsp;&nbsp;&nbsp;&nbsp;</label></b>
			<?php 
			preg_match_all('/"([^"]*)"/',stripcslashes($control['control_description']), $options); 
			//print_r($options[1]);
			?>
			<select id="<?php echo "select-box-".$control['control_id']; ?>" name="<?php echo esc_attr($control['control_name']); ?>">
				<option>---- Select ---- </option>
				<?php
				foreach($options[1] as $option){
				?>
				<option value="<?php echo esc_attr($option); ?>" <?php echo (get_post_meta($post->ID, $control['control_name'], true)== $option)?'selected':''; ?>><?php echo ucwords($option); ?></option>
				<?php
				}
				?>
				
			</select>
			</p>
			<?php
			
			}

			if($control['control_type']=='date-picker'){
			?>
			<p><b>
			<label for="<?php echo "date-picker-".$control['control_id']; ?>"><?php echo ucwords($control['control_label']); ?>:&nbsp;&nbsp;&nbsp;&nbsp;</label></b>
			<input type="date" id="<?php echo "date-picker-".$control['control_id']; ?>" name="<?php echo esc_attr($control['control_name']); ?>" value="<?php echo (get_post_meta($post->ID, $control['control_name'])=='')?date('Y-m-d'):get_post_meta($post->ID, $control['control_name'], true); ?>" >
			</p>
			<p><i><?php echo $control['control_description']; ?></i></p>
			<?php
			}

			if($control['control_type']=='color-picker'){
			?>
			<p><b>
			<label for="<?php echo "color-picker-".$control['control_id']; ?>"><?php echo ucwords($control['control_label']); ?>:&nbsp;&nbsp;&nbsp;&nbsp;</label></b>
			<input type="color" id="<?php echo "color-picker-".$control['control_id']; ?>" name="<?php echo esc_attr($control['control_name']); ?>" value="<?php echo get_post_meta($post->ID, $control['control_name'], true); ?>">
			</p>
			<p><i><?php echo $control['control_description']; ?></i></p>
			<?php
			}

			if($control['control_type']=='image-upload'){
			?>
			<hr/>
			<p><b><?php echo ucwords($control['control_label']); ?></b></p>
			<div class="wpdev-plugin image-upload" data-control-name="<?php echo esc_attr($control['control_name']); ?>">
				<?php $img_id = get_post_meta($post->ID, $control['control_name'], true); ?>
				<div class="img-preview">
				<?php 
				if($img_id>0){
					echo '<input type="hidden" name="'. $control['control_name'] .'" value="'. $img_id .'"> <img src="'. wp_get_attachment_url($img_id).'">';
				}
				?>
				</div>
				<button type="button" class="image-upload-btn button button-primary <?php echo ($img_id>0)?'hidden':''; ?>">Upload</button>
				<button type="button" class="image-upload-remove-btn button <?php echo ($img_id>0)?'':'hidden'; ?>">Remove</button>
			</div>
			<p><i><?php echo $control['control_description']; ?></i></p>
			<?php
			}

			if($control['control_type']=='image-gallery-upload'){
			?>
			<hr/>
			<p><b><?php echo ucwords($control['control_label']); ?></b></p>
			<div class="wpdev-plugin image-gallery-upload" data-control-name="<?php echo esc_attr($control['control_name']); ?>">
				<?php $images = unserialize(get_post_meta($post->ID, $control['control_name'], true)); ?>
				<div class="gallery-box">
				<ul>
					<?php
					if (!empty($images)) {
						foreach ($images as $image) {
							?>
							<li><img src="<?php echo wp_get_attachment_url($image); ?>"><input type="hidden" name="<?php echo $control['control_name']; ?>[]" value="<?php echo $image; ?>"><span class="remove">&times;</span></li>
							<?php
						}
					}
					?>
				</ul>
				</div>
				<button type="button" class="add-image-btn button button-primary">Add Images</button>
			</div>
			<p><i><?php echo $control['control_description']; ?></i></p>
			<?php
			}

			if($control['control_type']=='object-upload'){
			?>
			<p><b><?php echo ucwords($control['control_label']); ?></b></p>
			<div class="wpdev-plugin object-upload">
				<input type="text" style="width:220px" name="<?php echo esc_attr($control['control_name']); ?>"	value="<?php echo get_post_meta($post->ID, $control['control_name'], true); ?>">
				<button type="button" class="object-upload-btn button button-primary">Upload</button>
				<button type="button" class="object-upload-remove-btn button">Remove</button>
			</div>
			<p><i><?php echo $control['control_description']; ?></i></p>
			<?php
			}
		}
	}
}



add_action('save_post','WP_Dev_save_metabox',10,2);

function WP_Dev_save_metabox($post_id, $post){
	if(!isset($_POST['wpdev_meta_nonce'])|| !wp_verify_nonce($_POST['wpdev_meta_nonce'], basename(__FILE__)))
		return $post_id;
	
	if(!current_user_can('edit_post', $post->ID))
		return $post_id;
	
	$control = new WPDEV_Meta_Controls();
	if($post->post_type=='page'){
		$controlList = $control->getControlsArray('page','all-templates');
		$template = get_page_template_slug( $post->ID );
		$template= ($template=='')?'default-template':$template;
		$controlList2 = $control->getControlsArray('page', $template);
		$controlList = array_merge($controlList, $controlList2);
	}else{
		$controlList = $control->getControlsArray($post->post_type);
	}

	foreach($controlList as $control){
		$control = get_object_vars($control);
		if($control['control_type']!='tab'){
			if($control['control_type']=='image-gallery-upload'){
				$controlValue = serialize($_POST[$control['control_name']]);
			}else{
				$controlValue = sanitize_text_field($_POST[$control['control_name']]);
			}
			 
			update_post_meta($post_id, $control['control_name'], $controlValue);
		}
		
	}
}

?>