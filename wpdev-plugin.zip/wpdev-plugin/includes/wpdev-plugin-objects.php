<?php


class WPDEV_Objects{
	
	private $db_table;
	private $db;

	function __construct(){
		global $wpdb;
		$this->db = $wpdb;
		$this->db_table = $wpdb->prefix.'wpdev_post_tax';	
	}

	private function createObject($object_type, $object_name, $object_support, $singular_name, $plural_name, $hierarchical, $dashicon_class, $menu_position){
		$result = $this->db->insert($this->db_table, array(
			'object_type' => $object_type, 
			'object_name' => $object_name, 
			'object_support' => $object_support, 
			'singular_name'=> $singular_name, 
			'plural_name'=> $plural_name, 
			'hierarchical'=> $hierarchical,
			'dashicon_class'=>$dashicon_class,
			'menu_position'=> $menu_position
			)
		);
		return $result;
	}

	private function editObject($object_id, $object_support, $singular_name, $plural_name, $hierarchical, $dashicon_class, $menu_position){
		$result = $this->db->update($this->db_table, array(
			'object_support' => $object_support, 
			'singular_name'=> $singular_name, 
			'plural_name'=> $plural_name, 
			'hierarchical'=> $hierarchical,
			'dashicon_class'=> $dashicon_class,
			'menu_position'=> $menu_position
			), array('object_id'=>$object_id));
		return $result;
	}

	public function createPost($postType, $singularName, $pluralName, $dashiconClass, $menuPosition, $postSupport){
		$output = false;
		$postType = strtolower($postType);

		if($postType!= '' && $singularName!= '' && $pluralName!= ''){
			if(!post_type_exists($postType)){
				$dashiconClass = ($dashiconClass =='')?'dashicons-admin-post':$dashiconClass; 
				$menuPosition = ($menuPosition > 0 && $menuPosition < 100)?$menuPosition:20;
				$postSupport = trim(stripslashes($postSupport),'[]');
				
				$result = $this->createObject('post', $postType, $postSupport, $singularName, $pluralName, '', $dashiconClass, $menuPosition);

				if($result){
					$output = 'ok';
				}
				
			}else{
				$output = "Post type already exists.";
			}
		}else{
			$output = "Required fields are empty.";
		}
		return $output;

	}

	public function editPost($postId, $singularName, $pluralName, $dashiconClass, $menuPosition, $postSupport){
		$output = false;
		if($postId >= 0 && $singularName!= '' && $pluralName!= ''){
			$dashiconClass = ($dashiconClass =='')?'dashicons-admin-post':$dashiconClass; 
			$menuPosition = ($menuPosition > 0 && $menuPosition < 100)?$menuPosition:20;
			$postSupport = trim(stripslashes($postSupport),'[]');
			
			$result = $this->editObject($postId, $postSupport, $singularName, $pluralName, '', $dashiconClass, $menuPosition);

			if($result){
				$output = 'ok';
			}
		}else{
			$output = "Required fields are empty.";
		}
		return $output;

	}

	public function createTaxonomy($taxoName, $singularName, $pluralName, $thumbnailSupport, $hierarchical){
		$output = false;
		$taxoName = strtolower($taxoName);

		if($taxoName!= '' && $singularName!= '' && $pluralName!= ''){
			if(!taxonomy_exists($taxoName)){
				
				$result = $this->createObject('taxonomy', $taxoName, $thumbnailSupport, $singularName, $pluralName, $hierarchical, '', '',$privateAccess);

				if($result){
					$output = 'ok';
				}
				
			}else{
				$output = "Taxonomy already exists.";
			}
		}else{
			$output = "Required fields are empty.";
		}
		return $output;
	}

	public function editTaxonomy($taxoId, $singularName, $pluralName, $thumbnailSupport, $hierarchical){
		$output = false;
		if($taxoId >= 0 && $singularName!= '' && $pluralName!= ''){
			$result = $this->editObject($taxoId, $thumbnailSupport, $singularName, $pluralName, $hierarchical, '', '');

			if($result){
				$output = 'ok';
			}
		}else{
			$output = "Required fields are empty.";
		}
		return $output;
	}

	public function deleteObject($objectId){
		$result = $this->db->delete($this->db_table, array('object_id'=>$objectId));
		if($result){
			return "ok";
		}
		return false;
	}

	public function getObjectsByType($objectType){
		$result = $this->db->get_results( "SELECT * FROM ".$this->db_table." where `object_type` = '$objectType'" );
		return $result;
	}

}

?>