<?php

add_action( 'admin_menu', 'wpdev_plugin_menu');

function wpdev_plugin_menu(){
	add_menu_page( 'Wp Developer', 'Wp Developer', 'manage_options', 'wpdev-plugin', 'wpdevMainPage', 'dashicons-admin-appearance', 80);
}

function wpdevMainPage(){
	?>
	<div class="wrap">
		<div id="wpdevMainPage">
			<div class="card wpdev-login-div">
				<h2><?php echo __('Wp Developer', 'wpdev-plugin'); ?></h2>
				<form method="post" id="wpdev-login-form">
					<div class="row-field">
						<input type="password" placeholder="Password" name="wpdev-plugin-pswd" required/>
					</div>
					<div class="row-field">
						<input type="submit" class="bgcolor-blue" value="Login"/>
					</div>
					<div class="wpdev-login-response"></div>
					<p class="color-blue">
					<?php
						$user = new WPDEV_User();
						if($user->login('developer')){
							echo __('Default User','wpdev-plugin').'<br/>';
							echo "<b>". __('Password: ','wpdev-plugin')."</b> ";
							echo __('developer','wpdev-plugin');
						}
					?>
					</p>
					<div id="wpdev-footer"><?php echo __('Developed by:', 'wpdev-plugin'); ?> <a target="_blank" href="<?php echo esc_url('http://imdr.github.io/'); ?>"><?php echo __('Dinesh Rawat', 'wpdev-plugin'); ?></a></div>
				</form>
			</div>
		</div>
	</div>
	<?php
}