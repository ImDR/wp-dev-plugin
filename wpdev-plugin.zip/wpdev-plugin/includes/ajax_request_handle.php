<?php

add_action('wp_ajax_wpdev_plugin_ajax_handle','wpdev_plugin_ajax_handle');	

function wpdev_plugin_ajax_handle(){
	
	$route = sanitize_text_field(trim($_POST['route'],'/'));

	if($route == 'user/login'){
		$user = new WPDEV_User();
		$result = $user->login(sanitize_text_field($_POST['password']));
		if($result){
			$dashboard = new WPDEV_Dashboard();
			$dashboard->getDashboard();
		}else{
			echo "error";
		}
	}elseif($route == 'dashboard/menu'){
		$dashboard = new WPDEV_Dashboard();
		$menu = sanitize_text_field($_POST['menu-name']);
		if($menu=='change-password'){
			$dashboard->changePassword();
		}elseif($menu=='custom-posts'){
			$dashboard->customPosts();
		}elseif($menu=='custom-taxonomies'){
			$dashboard->customTaxonomy();
		}elseif($menu=='rel-posts-taxonomies'){
			$dashboard->relPostTaxonomy();
		}elseif($menu=='meta-builder'){
			$dashboard->metaBuilder();
		}

	}elseif($route == 'user/change-password'){
		$user = new WPDEV_User();
		echo $user->change_password(sanitize_text_field($_POST['password']), sanitize_text_field($_POST['new-password']), sanitize_text_field($_POST['new-password2']));
	}elseif($route == 'create/object/post'){
		$postType = str_replace('-','_',sanitize_key($_POST['post_name']));
		$singularName = sanitize_text_field($_POST['singular_name']);
		$pluralName = sanitize_text_field($_POST['plural_name']);
		$dashiconClass = sanitize_text_field($_POST['dashicon_class']);
		$menuPosition = intval($_POST['menu_position']);
		$postSupport = sanitize_text_field($_POST['post_support']);
		$object = new WPDEV_Objects();

		echo $object->createPost($postType, $singularName, $pluralName, $dashiconClass, $menuPosition, $postSupport);
	}elseif($route == 'edit/object/post'){
		$postId = intval($_POST['post_id']);
		$singularName = sanitize_text_field($_POST['singular_name']);
		$pluralName = sanitize_text_field($_POST['plural_name']);
		$dashiconClass = sanitize_text_field($_POST['dashicon_class']);
		$menuPosition = intval($_POST['menu_position']);
		$postSupport = sanitize_text_field($_POST['post_support']);
		$object = new WPDEV_Objects();

		echo $object->editPost($postId, $singularName, $pluralName, $dashiconClass, $menuPosition, $postSupport);
	}elseif($route == 'delete/object'){

		$objectId = intval($_POST['object_id']);
		$object = new WPDEV_Objects();

		echo $object->deleteObject($objectId);
	}elseif($route == 'create/object/taxonomy'){
		$taxoName = str_replace('-','_',sanitize_key($_POST['taxo_name']));
		$singularName = sanitize_text_field($_POST['singular_name']);
		$pluralName = sanitize_text_field($_POST['plural_name']);
		$thumbnailSupport = sanitize_text_field($_POST['thumbnail_support']);
		$hierarchical = sanitize_text_field($_POST['hierarchical']);
		$object = new WPDEV_Objects();

		echo $object->createTaxonomy($taxoName, $singularName, $pluralName, $thumbnailSupport, $hierarchical, $privateAccess);
	}elseif($route == 'edit/object/taxonomy'){
		$taxoId = intval($_POST['taxo_id']);
		$singularName = sanitize_text_field($_POST['singular_name']);
		$pluralName = sanitize_text_field($_POST['plural_name']);
		$thumbnailSupport = sanitize_text_field($_POST['thumbnail_support']);
		$hierarchical = sanitize_text_field($_POST['hierarchical']);
		$object = new WPDEV_Objects();

		echo $object->editTaxonomy($taxoId, $singularName, $pluralName, $thumbnailSupport, $hierarchical);
	}elseif($route == 'create/relationship'){
		$postName = sanitize_text_field($_POST['post_name']);
		$taxonomyName = sanitize_text_field($_POST['taxonomy_name']);
		$rel = new WPDEV_Relationships();
		echo $rel->createRelationship($postName, $taxonomyName);
	}elseif($route == 'delete/relationship'){
		$relId = intval($_POST['rel_id']);
		$rel = new WPDEV_Relationships();
		echo $rel->deleteRelationship($relId);
	}elseif($route == 'load/meta'){
		$postType = sanitize_text_field($_POST['post_type']);
		$controls = new WPDEV_Meta_Controls();
		if($postType == 'page'){
			$templateName = sanitize_text_field($_POST['template_name']);
			$controls->getPageControlsHtml($postType,$templateName);
		}else{
			$controls->getPostControlsHtml($postType);
		}
	}elseif($route == 'create/meta-control') {
		$postType = sanitize_text_field($_POST['post_type']);
		$controlType = sanitize_text_field($_POST['control_type']);
		if($postType!='' && $controlType!=''){
			$control_label = sanitize_text_field(stripcslashes($_POST['control_label']));
			$control_name = sanitize_key($_POST['control_name']);
			$control_description = sanitize_text_field(stripcslashes($_POST['description']));
			$control_order = sanitize_text_field($_POST['control_order']);
			$controls = new WPDEV_Meta_Controls();
			if($controls->postTypeHasMeta($postType, $control_name)){
				if($postType=='page'){
					$template_name = sanitize_text_field($_POST['template_name']);
					$result = $controls->createControl($controlType, $control_name, $control_label, $postType, $template_name, $control_description, $control_order);
					if($result){
						echo "ok";
					}
				}else{
					$result = $controls->createControl($controlType, $control_name, $control_label, $postType, '', $control_description, $control_order);
					if($result){
						echo "ok";
					}
				}
			}else{
				echo "Meta Control Name already exists";
			}
			
		}
	}elseif($route == 'update/meta-control') {
		$control_id = intval($_POST['control_id']);
		$control_label = sanitize_text_field(stripcslashes($_POST['control_label']));
		$control_description = sanitize_text_field(stripcslashes($_POST['description']));
		if ($control_id>0) {
			if($control_label !=''){
				$controls = new WPDEV_Meta_Controls();
				$result = $controls->editControl($control_id, $control_label, $control_description);
				if($result){
					echo "ok";
				}
			}else{
				echo "Meta Label is invaild.";
			}
		}
	
		

	}elseif($route == 'update/control-order'){
		$arr = json_decode(stripcslashes($_POST['control_order']), true);
		$controls = new WPDEV_Meta_Controls();
		
		foreach ($arr as $item){
			$controls->changeOrder(intval($item["controlId"]), intval($item["index"]));
		}
	}elseif ($route == 'remove/control') {
		$controls = new WPDEV_Meta_Controls();
		$result = $controls->removeControlById(intval($_POST["removeControlId"]));
		if($result){
			echo "ok";
		}else{
			echo "error";
		}
	}

	wp_die();
}

?>