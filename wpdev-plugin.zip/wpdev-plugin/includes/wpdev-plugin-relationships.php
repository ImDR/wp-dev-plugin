<?php


class WPDEV_Relationships{
	private $db_table;
	private $db;

	function __construct(){
		global $wpdb;
		$this->db = $wpdb;
		$this->db_table = $wpdb->prefix.'wpdev_posts_tax_rel';	
	}

	function getAllRelationships(){
		$result = $this->db->get_results( "SELECT * FROM ".$this->db_table );
		return $result;
	}

	function createRelationship($postTypeName, $taxonomyName){
		$output = false;
		if(!is_object_in_taxonomy( $postTypeName, $taxonomyName )){
			$result = $this->db->insert($this->db_table, array(
				'post_type_name' => $postTypeName, 
				'taxonomy_name' => $taxonomyName
				)
			);
			if($result){
				$output = "ok";
			}
		}else{
			$output = "Already associated.";
		}
		return $output;
	}

	function deleteRelationship($id){
		$result = $this->db->delete($this->db_table, array('id'=>$id));
		if($result){
			return "ok";
		}
		return false;
	}
}

?>