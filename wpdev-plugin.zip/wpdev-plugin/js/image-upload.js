jQuery(function($){

	$('.wpdev-plugin.image-upload').on('click', '.image-upload-btn', function(event) {
		event.preventDefault();
		var control_container = $(this).parents('.wpdev-plugin.image-upload');
		var control_name = $(control_container).attr('data-control-name');
		var preview = $(control_container).find('.img-preview');

		var frame = wp.media({
		  title: 'Select or Upload Image',
		  button: {
			text: 'Use this image'
		  },
		  multiple: false 
		});

		frame.on( 'select', function() {
			var attachment = frame.state().get('selection').first().toJSON();
			$(preview).html('<input type="hidden" name="'+ control_name +'" value="'+ attachment.id +'"/> <img src="'+ attachment.url +'"/>');
			$(control_container).find('.image-upload-remove-btn').removeClass('hidden');
			$(control_container).find('.image-upload-btn').addClass('hidden');


		});

		frame.open();
	});

	$('.wpdev-plugin.image-upload').on('click', '.image-upload-remove-btn', function(event) {
		event.preventDefault();
		var control_container = $(this).parents('.wpdev-plugin.image-upload');
		$(control_container).find('.img-preview').html('');
		$(control_container).find('.image-upload-remove-btn').addClass('hidden');
		$(control_container).find('.image-upload-btn').removeClass('hidden');

	});

	$('.wpdev-plugin.image-gallery-upload').on('click', '.add-image-btn', function(event) {
		event.preventDefault();
		var control_container = $(this).parents('.wpdev-plugin.image-gallery-upload');
		var control_name = $(control_container).attr('data-control-name');
		var gallery_box = $(control_container).find('.gallery-box ul');

		var frame = wp.media({
		  title: 'Select multiple images with the CTRL key',
		  button: {
			text: 'Upload'
		  },
		  multiple: true 
		});

		frame.on( 'select', function() {
			var attachment = frame.state().get('selection').toJSON();
			for(var i=0; i< attachment.length; i++){
				$(gallery_box).append("<li><img src='"+attachment[i].url+"'/><input type='hidden' name='"+control_name+"[]' value='"+attachment[i].id+"'/><span class='remove'>&times;</span></li>");
				//console.log(attachment[i].id);
			}
		});

		frame.open();
	});

	$('.wpdev-plugin.image-gallery-upload').on('click', '.gallery-box ul li span.remove', function(event) {
		event.preventDefault();
		$(this).parent('li').remove();
	});

	$('.wpdev-plugin.object-upload').on('click', '.object-upload-btn', function(event) {
		event.preventDefault();
		var control_container = $(this).parents('.wpdev-plugin.object-upload');
		var frame = wp.media({
		  title: 'Select or Upload',
		  button: {
			text: 'Use this'
		  },
		  multiple: false 
		});

		frame.on( 'select', function() {
			var attachment = frame.state().get('selection').first().toJSON();
			$(control_container).find('input').val(attachment.url);
		});

		frame.open();
	});

	$('.wpdev-plugin.object-upload').on('click', '.object-upload-remove-btn', function(event) {
		event.preventDefault();
		var control_container = $(this).parents('.wpdev-plugin.object-upload');
		$(control_container).find('input').val('');

	});

	$(document).ready(function(){
		$('.wpdev-plugin-theme-option').find(".tab-content").eq(0).addClass('tab-active');
		$('.wpdev-plugin-theme-option').find(".nav-tab-wrapper .nav-tab").eq(0).addClass('nav-tab-active');
	});

	$('.wpdev-plugin-theme-option .nav-tab-wrapper .nav-tab').on('click', function() {
		if(!$(this).hasClass('nav-tab-active')){
			var tabPressed = $(this).index();
			$('.wpdev-plugin-theme-option').find(".tab-content").removeClass('tab-active');
			$('.wpdev-plugin-theme-option').find(".nav-tab-wrapper .nav-tab").removeClass('nav-tab-active');
			$('.wpdev-plugin-theme-option').find(".tab-content").eq(tabPressed).addClass('tab-active');
			$('.wpdev-plugin-theme-option').find(".nav-tab-wrapper .nav-tab").eq(tabPressed).addClass('nav-tab-active');
		}
	});

});