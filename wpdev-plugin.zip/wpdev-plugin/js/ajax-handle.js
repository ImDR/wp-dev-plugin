jQuery(function($){

	var AJAX_URL = ajax_object.ajax_url;
	var AJAX_ACTION = 'wpdev_plugin_ajax_handle';

	var wpdevMainPage = $('#wpdevMainPage');

	//alert(AJAX_URL);
	
	function wpdev_login(password){
			var wpdev_login_response = $('.wpdev-login-response');
			var data = {
				'action': AJAX_ACTION,
				'route' : 'user/login',
				'password': password
			};

			$(wpdev_login_response).html('<p class="color-green">Loading...</p>');

			$.ajax({
				url: AJAX_URL,
				type: 'POST',
				dataType: 'html',
				data: data,
			})
			.done(function(data) {
				if(data=="error"){
					$(wpdev_login_response).html('<p class="color-red">Password is invalid.</p>');
					$(pswd).val('');
				}else{
					$(wpdevMainPage).html(data);
					sessionStorage.setItem('password',password);
				}
			})
			.fail(function() {
				$(wpdev_login_response).html('<p class="color-red">Something went wrong.</p>');
			})
			.always(function() {
				console.log("complete");
			});
	}

	$(document).on('submit','#wpdev-login-form', function(event) {
		event.preventDefault();
		var wpdev_login_response = $('.wpdev-login-response');
		$(wpdev_login_response).html('');

		var pswd = $(this).find('input[name="wpdev-plugin-pswd"]');
		if($(pswd).val().length>0){
			var password = $(pswd).val();
			wpdev_login(password);
		}else{
			$(wpdev_login_response).html('<p class="color-red">Password is required.</p>');
		}
	});

	$(document).ready(function() {
		if(sessionStorage.getItem('password') && sessionStorage.getItem('password').length > 0){
			wpdev_login(sessionStorage.getItem('password'));
		}
	});

	$(document).on('click', '.collapse-box .collapse-head .toggle-btn', function(event) {
		event.preventDefault();
		
		if($(this).hasClass('active')){
			$(this).parents('.collapse-box').find('.collapse-body').slideUp('fast');
			$('.collapse-box .collapse-head .toggle-btn').removeClass('active');
		}else{
			$('.collapse-box .collapse-head .toggle-btn').removeClass('active');
			$('.collapse-box .collapse-body').slideUp('fast');
			$(this).addClass('active');
			$(this).parents('.collapse-box').find('.collapse-body').slideDown('fast');
		}
	});

	function response_msg(msg, type){
		var response;
		if(type == 'success'){
			response = "<span class='color-green'>"+ msg +"</span>";
		}else if(type == 'warning'){
			response = "<span class='color-yellow'>"+ msg +"</span>";
		}else{
			response = "<span class='color-red'>"+ msg +"</span>";
		}

		$('#wpdevMainPage .response-text').html(response);
	}

	function loading(){
		response_msg('Loading...', 'success');
	}

	function server_error(){
		response_msg('Something went wrong.');
	}

	function clear_msg(){
		response_msg('');
	}

	function load_menu(menu_name){
		var data = {
				'action': AJAX_ACTION,
				'route' : 'dashboard/menu',
				'menu-name': menu_name
			};
			loading();
			$.ajax({
				url: AJAX_URL,
				type: 'POST',
				dataType: 'html',
				data: data,
			})
			.done(function(data) {
				clear_msg();
				$('#wpdev-dashboard-container').html(data);
			})
			.fail(function() {
				server_error();
			})
			.always(function() {
				console.log("complete");
			});
	}

	function reload(){
		var menu_name = $('.wpdev-dashboard-menu span.nav-tab.nav-tab-active').attr('data-menu-name');
		load_menu(menu_name);
	}

	$(document).on('click', '.wpdev-dashboard-menu span.nav-tab', function(event) {
		event.preventDefault();
		
		//alert($(this).attr('data-menu-name'));
		if(!$(this).hasClass('nav-tab-active')){
			$('.wpdev-dashboard-menu span').removeClass('nav-tab-active');
			$(this).addClass('nav-tab-active');
			var menu_name = $(this).attr('data-menu-name');
			load_menu(menu_name);
		}

	});

	
	$(document).on('click', '#wpdevMainPage .reload', function(event) {
		reload();
	});

	$(document).on('submit', '#wpdevMainPage .wpdev-changepswd-form', function(event) {
		event.preventDefault();
		clear_msg();
		var new_password = $(this).find('input[name="wpdev-plugin-new-pswd"]').val();
		var new_password2 = $(this).find('input[name="wpdev-plugin-new2-pswd"]').val();
		var password = $(this).find('input[name="wpdev-plugin-pswd"]').val();
		if(password!='' && new_password!='' && new_password2!=''){
			if(new_password == new_password2){
				
				var data = {
					'action': AJAX_ACTION,
					'route' : 'user/change-password',
					'password': password,
					'new-password': new_password,
					'new-password2': new_password2
				};
				loading();
				$.ajax({
					url: AJAX_URL,
					type: 'POST',
					dataType: 'html',
					data: data,
				})
				.done(function(data) {
					if(data=='ok'){
						response_msg('Password successfully changed.', 'success');
						reload();
					}else{
						response_msg(data, 'error');
					}
				})
				.fail(function() {
					server_error();
				})
				.always(function() {
					
					console.log("complete");
				});
			
			}else{
				response_msg('Password does not match the confirm password.', 'warning');
			}
		}
	});


	$(document).on('submit', '#wpdevMainPage .wpdev-createcustompost', function(event) {
		event.preventDefault();
		clear_msg();
		var post_name = $(this).find('input[name="wpdev-post-name"]').val().trim();
		var singular_name = $(this).find('input[name="wpdev-singular-name"]').val().trim();
		var plural_name = $(this).find('input[name="wpdev-plural-name"]').val().trim();
		
		if (post_name.length > 0 && singular_name.length > 0 && plural_name.length > 0) {
			var dashicon_class = $(this).find('input[name="wpdev-dashicon-class"]').val().trim();
			var menu_position = $(this).find('input[name="wpdev-menu-position"]').val().trim();
			var post_support = $(this).find('input[name="wpdev-post-support"]:checked');
			var support = []; 
			$(post_support).each(function(index, el) {
				support.push($(el).val());
			});
			loading();

			var data = {
				'action': AJAX_ACTION,
				'route' : 'create/object/post',
				'post_name': post_name,
				'singular_name': singular_name,
				'plural_name': plural_name,
				'dashicon_class': dashicon_class,
				'menu_position': menu_position,
				'post_support': JSON.stringify(support)
			};

			$.ajax({
				url: AJAX_URL,
				type: 'POST',
				dataType: 'html',
				data: data,
			})
			.done(function(data) {
				if(data =="ok"){
					reload();
				}else{
					response_msg(data, 'error');
				}
			})
			.fail(function() {
				server_error();
			})
			.always(function() {
				console.log("complete");
			});
		}else{
			response_msg('Required fields are empty.', 'warning');
		}
	});

	$(document).on('submit', '#wpdevMainPage .wpdev-editcustompost', function(event) {
		event.preventDefault();
		clear_msg();
		var post_id = $(this).find('input[name="wpdev-post-id"]').val().trim();
		var singular_name = $(this).find('input[name="wpdev-singular-name"]').val().trim();
		var plural_name = $(this).find('input[name="wpdev-plural-name"]').val().trim();
		
		if (post_id.length > 0 && singular_name.length > 0 && plural_name.length > 0) {
			var dashicon_class = $(this).find('input[name="wpdev-dashicon-class"]').val().trim();
			var menu_position = $(this).find('input[name="wpdev-menu-position"]').val().trim();
			var post_support = $(this).find('input[name="wpdev-post-support"]:checked');
			var support = []; 
			$(post_support).each(function(index, el) {
				support.push($(el).val());
			});
			loading();

			var data = {
				'action': AJAX_ACTION,
				'route' : 'edit/object/post',
				'post_id': post_id,
				'singular_name': singular_name,
				'plural_name': plural_name,
				'dashicon_class': dashicon_class,
				'menu_position': menu_position,
				'post_support': JSON.stringify(support)
			};

			$.ajax({
				url: AJAX_URL,
				type: 'POST',
				dataType: 'html',
				data: data,
			})
			.done(function(data) {
				if(data =="ok"){
					reload();
				}else{
					response_msg(data, 'error');
				}
			})
			.fail(function() {
				server_error();
			})
			.always(function() {
				console.log("complete");
			});
		}else{
			response_msg('Required fields are empty.', 'warning');
		}
	});


	$(document).on('submit', '#wpdevMainPage .wpdev-createcustomtaxonomy', function(event) {
		event.preventDefault();
		clear_msg();
		var taxo_name = $(this).find('input[name="wpdev-taxo-name"]').val().trim();
		var singular_name = $(this).find('input[name="wpdev-singular-name"]').val().trim();
		var plural_name = $(this).find('input[name="wpdev-plural-name"]').val().trim();
		
		if (taxo_name.length > 0 && singular_name.length > 0 && plural_name.length > 0) {
			var thumbnail_support = $(this).find('input[name="wpdev-taxo-thumbnail"]').is(':checked');
			var hierarchical = $(this).find('input[name="wpdev-taxo-hierarchical"]').is(':checked');
			loading();
			var data = {
				'action': AJAX_ACTION,
				'route' : 'create/object/taxonomy',
				'taxo_name': taxo_name,
				'singular_name': singular_name,
				'plural_name': plural_name,
				'thumbnail_support': thumbnail_support,
				'hierarchical': hierarchical
			};

			$.ajax({
				url: AJAX_URL,
				type: 'POST',
				dataType: 'html',
				data: data,
			})
			.done(function(data) {
				if(data =="ok"){
					reload();
				}else{
					response_msg(data, 'error');
				}
			})
			.fail(function() {
				server_error();
			})
			.always(function() {
				console.log("complete");
			});
		}else{
			response_msg('Required fields are empty.', 'warning');
		}
	});
	
	$(document).on('submit', '#wpdevMainPage .wpdev-editcustomtaxonomy', function(event) {
		event.preventDefault();
		clear_msg();
		var taxo_id = $(this).find('input[name="wpdev-taxo-id"]').val().trim();
		var singular_name = $(this).find('input[name="wpdev-singular-name"]').val().trim();
		var plural_name = $(this).find('input[name="wpdev-plural-name"]').val().trim();
		
		if (taxo_id.length > 0 && singular_name.length > 0 && plural_name.length > 0) {
			var thumbnail_support = $(this).find('input[name="wpdev-taxo-thumbnail"]').is(':checked');
			var hierarchical = $(this).find('input[name="wpdev-taxo-hierarchical"]').is(':checked');
			loading();
			var data = {
				'action': AJAX_ACTION,
				'route' : 'edit/object/taxonomy',
				'taxo_id': taxo_id,
				'singular_name': singular_name,
				'plural_name': plural_name,
				'thumbnail_support': thumbnail_support,
				'hierarchical': hierarchical
			};

			$.ajax({
				url: AJAX_URL,
				type: 'POST',
				dataType: 'html',
				data: data,
			})
			.done(function(data) {
				if(data =="ok"){
					reload();
				}else{
					response_msg(data, 'error');
				}
			})
			.fail(function() {
				server_error();
			})
			.always(function() {
				console.log("complete");
			});
		}else{
			response_msg('Required fields are empty.', 'warning');
		}
	});
	
	$(document).on('submit', '#wpdevMainPage .wpdev-relposttaxonomy', function(event) {
		event.preventDefault();
		clear_msg();
		if ($(this).find('select[name="wpdev-rel-post"]').val()!== null && $(this).find('select[name="wpdev-rel-taxonomy"]').val() !==null) {
			var post_name = $(this).find('select[name="wpdev-rel-post"]').val();
			var taxonomy_name = $(this).find('select[name="wpdev-rel-taxonomy"]').val();
			loading();
			var data = {
				'action': AJAX_ACTION,
				'route' : 'create/relationship',
				'post_name': post_name,
				'taxonomy_name': taxonomy_name
			};

			$.ajax({
				url: AJAX_URL,
				type: 'POST',
				dataType: 'html',
				data: data,
			})
			.done(function(data) {
				if(data =="ok"){
					reload();
				}else{
					response_msg(data, 'error');
				}
			})
			.fail(function() {
				server_error();
			})
			.always(function() {
				console.log("complete");
			});

		}else{
			response_msg('Required fields are empty.', 'warning');
		}
	});

	$(document).on('click', '#wpdevMainPage .collapse-head span.remove', function(event) {
		event.preventDefault();
		clear_msg();
		var object_id = $(this).attr('data-objectId');
		if(object_id > 0){
			var r = confirm("Do you want to delete this object?");
			if(r){
				loading();
				var data = {
					'action': AJAX_ACTION,
					'route' : 'delete/object',
					'object_id': object_id,
				};
				$.ajax({
					url: AJAX_URL,
					type: 'POST',
					dataType: 'html',
					data: data,
				})
				.done(function(data) {
					if(data =="ok"){
						reload();
					}else{
						server_error();
					}
				})
				.fail(function() {
					server_error();
				})
				.always(function() {
					console.log("complete");
				});
			}
			
		}else{
			server_error();
		}
	});


	$(document).on('click', '#wpdevMainPage .collapse-head span.remove-rel', function(event) {
		event.preventDefault();
		clear_msg();
		var rel_id = $(this).attr('data-relId');
		if(rel_id > 0){
			var r = confirm("Do you want to delete this relationship?");
			if(r){
				loading();
				var data = {
					'action': AJAX_ACTION,
					'route' : 'delete/relationship',
					'rel_id': rel_id,
				};
				$.ajax({
					url: AJAX_URL,
					type: 'POST',
					dataType: 'html',
					data: data,
				})
				.done(function(data) {
					if(data =="ok"){
						reload();
					}else{
						server_error();
					}
				})
				.fail(function() {
					server_error();
				})
				.always(function() {
					console.log("complete");
				});
			}
			
		}else{
			server_error();
		}
	});


	$(document).on('change', '#wpdevMainPage select[name="wpdev-mbpost"]', function(event) {
		event.preventDefault();
		var post_type = $(this).val();
		if(post_type == 'page'){
			$('#wpdevMainPage select[name="wpdev-mbtemplate"]').show();
		}else{
			$('#wpdevMainPage select[name="wpdev-mbtemplate"]').hide();
			loading();
			var data = {
				'action': AJAX_ACTION,
				'route' : 'load/meta',
				'post_type': post_type,
			};
			$.ajax({
				url: AJAX_URL,
				type: 'POST',
				dataType: 'html',
				data: data,
			})
			.done(function(data) {
				clear_msg();
				$('#wpdevMainPage .metaBuilderContainer').html(data);
				load_list();
			})
			.fail(function() {
				server_error();
			})
			.always(function() {
				console.log("complete");
			});
		}
	});

	$(document).on('change', '#wpdevMainPage select[name="wpdev-mbtemplate"]', function(event) {
		event.preventDefault();
		var template_name = $(this).val();
		loading();
		var data = {
			'action': AJAX_ACTION,
			'route' : 'load/meta',
			'post_type': 'page',
			'template_name' : template_name
		};
		$.ajax({
			url: AJAX_URL,
			type: 'POST',
			dataType: 'html',
			data: data,
		})
		.done(function(data) {
			clear_msg();
			$('#wpdevMainPage .metaBuilderContainer').html(data);
			load_list();
		})
		.fail(function() {
			server_error();
		})
		.always(function() {
			console.log("complete");
		});
		
	});

	$(document).on('change', '#wpdevMainPage select[name="wpdev-mbcontroltype"]', function(event) {
		event.preventDefault();
		$('#wpdevMainPage input[name="wpdev-mbcontrolname"]').show();
		$('#wpdevMainPage textarea[name="wpdev-mbcontroldescription"]').show();
		$('#wpdevMainPage textarea[name="wpdev-mbcontroldescription"]').attr('placeholder', 'Message');
		var control_type = $(this).val();
		if(control_type == 'tab'){
			$('#wpdevMainPage input[name="wpdev-mbcontrolname"]').hide();
			$('#wpdevMainPage textarea[name="wpdev-mbcontroldescription"]').hide();
		}else if(control_type == 'select-box'){
			$('#wpdevMainPage textarea[name="wpdev-mbcontroldescription"]').attr('placeholder', '"option1", "option2", "option3"');
		}
	});

	$(document).on('submit', '#wpdevMainPage .wpdev-createmetacontrol', function(event) {
		event.preventDefault();
		clear_msg();
		var post_type = $(this).find('input[name="wpdev-post-type"]').val();
		if (post_type!== '' ) {
			var data = {
				'action': AJAX_ACTION,
				'route' : 'create/meta-control',
				'post_type': post_type
			};

			if(post_type=='page'){
				var template_name = $(this).find('input[name="wpdev-template-name"]').val();
				if (template_name !==null) {
					data.template_name = template_name;
				}else{
					response_msg('Template is not selected.', 'error');
					return false;
				}
			}

			var control_type = $(this).find('select[name="wpdev-mbcontroltype"]').val();

			if(control_type === null){
				response_msg('Meta Control Type is not selected.', 'error');
				return false;
			}

			var control_label = $(this).find('input[name="wpdev-mbcontrollabel"]').val();
			if(control_label == ''){
				response_msg('Control Label field is required.', 'error');
				return false;
			}
			
			var control_name = $(this).find('input[name="wpdev-mbcontrolname"]').val();
			
			if(control_type!='tab'){
				if(control_name == ''){
					response_msg('Control Name field is required.', 'error');
					return false;
				}
			}else{
				control_name = 'tab';
			}

			data.control_type = control_type;
			data.control_label = control_label;
			data.control_name = control_name;
			data.control_order = parseInt($('#controls-list li').length) + 1;
			data.description = $(this).find('textarea[name="wpdev-mbcontroldescription"]').val();
			$.ajax({
				url: AJAX_URL,
				type: 'POST',
				dataType: 'html',
				data: data,
			})
			.done(function(data) {
				clear_msg();
				if(data!='ok'){
					response_msg(data, 'error');
				}else{
					$('#wpdevMainPage select[name="wpdev-mbpost"]').trigger('change');
					if(post_type=='page')
						$('#wpdevMainPage select[name="wpdev-mbtemplate"]').trigger('change');
				}
			})
			.fail(function() {
				server_error();
			})
			.always(function() {
				
				console.log("complete");
			});
			
			
		}else{
			response_msg('Post Type is not selected.', 'error');
		}
	});

	$(document).on('submit', '#wpdevMainPage .wpdev-updatemetacontrol', function(event) {
		event.preventDefault();
		clear_msg();
		var control_label = $(this).find('input[name="wpdev-mbcontrollabel"]').val();
		var control_id = $(this).find('input[name="wpdev-control-id"]').val();
		var description = $(this).find('textarea[name="wpdev-mbcontroldescription"]').val();
		if(description===undefined){
			description = "";
		}
		if(control_id>0){
			if(control_label!=''){
				var data = {
					'action': AJAX_ACTION,
					'route' : 'update/meta-control',
					'control_id': control_id,
					'control_label': control_label,
					'description': description
				};



				$.ajax({
					url: AJAX_URL,
					type: 'POST',
					dataType: 'html',
					data: data,
				})
				.done(function(data) {
					clear_msg();
					if(data!='ok'){
						response_msg(data, 'error');
					}else{
						$('#wpdevMainPage select[name="wpdev-mbpost"]').trigger('change');
						if($('#wpdevMainPage select[name="wpdev-mbpost"]').val()=='page')
							$('#wpdevMainPage select[name="wpdev-mbtemplate"]').trigger('change');
					}
				})
				.fail(function() {
					server_error();
				})
				.always(function() {
					
					console.log("complete");
				});
			}else{
				response_msg('Control Label field is required.', 'error');
			}
		}
			
	});

	function load_list(){
		clear_msg();
		
		var list = document.getElementById("controls-list");
		Sortable.create(list,{
			animation: 150,
			handle: ".handle",
			filter: '.remove-control',
			onFilter: function (evt) {
				var r = confirm('Do you want to delete this control?');
				if(r){
					evt.item.parentNode.removeChild(evt.item);
					var removeControlId = $(evt.item).attr('data-control-id');
					console.log(removeControlId);
					var data = {
						'action': AJAX_ACTION,
						'route' : 'remove/control',
						'removeControlId': removeControlId
					};
					
					$.ajax({
						url: AJAX_URL,
						type: 'POST',
						dataType: 'html',
						data: data,
					})
					.done(function(data) {
						console.log(data);
					})
					.fail(function() {
						console.log("error");
					})
					.always(function() {
						console.log("complete");
					});
				}
			},
			onEnd: function(evt){
				var controlOrder = [];
				$(list).children('li[data-control-id]').each(function(){
					var controlId = $(this).attr('data-control-id');
					var index = $(this).index() + 1;
					controlOrder.push( {
						'controlId': controlId,
						'index' : index
					});
				});
				controlOrder = JSON.stringify(controlOrder);
				var data = {
					'action': AJAX_ACTION,
					'route' : 'update/control-order',
					'control_order': controlOrder
				};
				$.ajax({
					url: AJAX_URL,
					type: 'POST',
					dataType: 'html',
					data: data,
				})
				.done(function(data) {
					console.log(data);
				})
				.fail(function() {
					console.log("error");
				})
				.always(function() {
					console.log("complete");
				});
			}
		
		});
	}
});